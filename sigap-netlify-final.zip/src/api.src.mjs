// SIGAP IM3 - backend untuk Netlify Functions (port dari api.php).
// Database: MySQL/MariaDB eksternal, diatur lewat environment variable di Netlify:
//   DB_HOST, DB_PORT (3306), DB_NAME, DB_USER, DB_PASS, DB_SSL ("false" untuk mematikan TLS), SESSION_SECRET
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';

export const config = { path: ['/api.php', '/uploads/*'] };

const TIPE = ['Visit Toko', 'Training', 'Meeting', 'Sosialisasi'];
const MAX_PHOTOS = 3;
const MAX_PHOTO_BYTES = 3 * 1024 * 1024;
const MIN_PASS = 6;
const LOGIN_MAX_USER = 8;
const LOGIN_MAX_IP = 40;
const LOGIN_WINDOW = 900; // detik
const SESSION_DAYS = 7;
const DEFAULT_SALES_PASSWORD = 'im3kupang';
const DEFAULT_ADMIN_PASSWORD = 'admin123';

/* ---------- response helpers ---------- */
const BASE_HEADERS = {
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
};
class Out extends Error {
  constructor(body, status = 200, headers = {}) { super('out'); this.body = body; this.status = status; this.headers = headers; }
}
const out = (d, c = 200, h = {}) => { throw new Out(d, c, h); };
const err = (m, c = 400) => out({ error: m }, c);
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- koneksi & skema ---------- */
let pool = null, ready = null;
function getPool() {
  if (pool) return pool;
  const e = process.env;
  if (!e.DB_HOST || !e.DB_NAME || !e.DB_USER) throw new Error('Variabel DB_HOST / DB_NAME / DB_USER belum diisi di Netlify');
  const ssl = e.DB_SSL === 'false' ? undefined
    : e.DB_SSL === 'no-verify' ? { minVersion: 'TLSv1.2', rejectUnauthorized: false }
    : { minVersion: 'TLSv1.2', rejectUnauthorized: true };
  pool = mysql.createPool({
    host: e.DB_HOST.trim(), port: Number(e.DB_PORT || 3306), database: e.DB_NAME.trim(), user: e.DB_USER.trim(), password: e.DB_PASS || '',
    ssl, charset: 'utf8mb4', connectionLimit: 4, waitForConnections: true, connectTimeout: 8000,
  });
  return pool;
}
const T = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci';
const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS sales (id_sales VARCHAR(40) NOT NULL, nama VARCHAR(80) NOT NULL, aktif TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id_sales), UNIQUE KEY uq_sales_nama (nama)) ${T}`,
  `CREATE TABLE IF NOT EXISTS users (id INT UNSIGNED NOT NULL AUTO_INCREMENT, username VARCHAR(40) NOT NULL, nama VARCHAR(80) NOT NULL, role ENUM('admin','sales') NOT NULL, password_hash VARCHAR(255) NOT NULL, id_sales VARCHAR(40) NULL DEFAULT NULL, must_change TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), UNIQUE KEY uq_users_username (username), UNIQUE KEY uq_users_id_sales (id_sales)) ${T}`,
  `CREATE TABLE IF NOT EXISTS settings (k VARCHAR(40) NOT NULL, v VARCHAR(255) NOT NULL, PRIMARY KEY (k)) ${T}`,
  `CREATE TABLE IF NOT EXISTS posts (id INT UNSIGNED NOT NULL AUTO_INCREMENT, ts BIGINT NOT NULL, id_sales VARCHAR(40) NULL DEFAULT NULL, sales_nama VARCHAR(80) NOT NULL, tipe ENUM('Visit Toko','Training','Meeting','Sosialisasi') NOT NULL, area VARCHAR(60) NOT NULL, fields TEXT NOT NULL, note TEXT NOT NULL, PRIMARY KEY (id), KEY idx_posts_ts (ts), KEY idx_posts_sales (sales_nama, ts)) ${T}`,
  `CREATE TABLE IF NOT EXISTS post_photos (id INT UNSIGNED NOT NULL AUTO_INCREMENT, post_id INT UNSIGNED NOT NULL, path VARCHAR(255) NOT NULL, urutan TINYINT NOT NULL DEFAULT 0, PRIMARY KEY (id), KEY idx_photos_post (post_id)) ${T}`,
  // Netlify tidak punya disk permanen: isi foto disimpan di database.
  `CREATE TABLE IF NOT EXISTS photo_blobs (name VARCHAR(80) NOT NULL, data MEDIUMBLOB NOT NULL, PRIMARY KEY (name)) ${T}`,
  `CREATE TABLE IF NOT EXISTS comments (id INT UNSIGNED NOT NULL AUTO_INCREMENT, post_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NULL DEFAULT NULL, nama VARCHAR(80) NOT NULL, username VARCHAR(40) NOT NULL, teks VARCHAR(300) NOT NULL, ts BIGINT NOT NULL, PRIMARY KEY (id), KEY idx_comments_post (post_id)) ${T}`,
  `CREATE TABLE IF NOT EXISTS login_attempts (id INT UNSIGNED NOT NULL AUTO_INCREMENT, k VARCHAR(60) NOT NULL, ts BIGINT NOT NULL, PRIMARY KEY (id), KEY idx_la_k_ts (k, ts)) ${T}`,
];
async function init() {
  const p = getPool();
  // Cek tabel yang sudah ada; hanya buat yang belum ada (DDL ke database cloud bisa lambat).
  const have = new Set((await p.query('SELECT table_name AS t FROM information_schema.tables WHERE table_schema = DATABASE()'))[0].map(r => String(r.t).toLowerCase()));
  for (const s of SCHEMA) {
    const name = /EXISTS (\w+)/.exec(s)[1];
    if (!have.has(name)) await p.query(s);
  }
  const n = Number((await p.query('SELECT COUNT(*) AS n FROM users'))[0][0].n);
  if (n === 0) {
    await p.execute('INSERT INTO settings(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=v', ['target', '5']);
    await p.execute('INSERT INTO users(username,nama,role,password_hash,must_change) VALUES(?,?,?,?,1)',
      ['admin', 'Supervisor IM3', 'admin', await bcrypt.hash(DEFAULT_ADMIN_PASSWORD, 10)]);
  }
}
const ensureReady = () => (ready ||= init().catch(e => { ready = null; throw e; }));

/* ---------- util ---------- */
const clean = (s, max) => Array.from(String(s ?? '').replace(/\s+/g, ' ').trim()).slice(0, max).join('');
const uname = s => String(s ?? '').trim().toLowerCase().replace(/[^a-z0-9._]/g, '');
const usernameFromName = nama => (String(nama).trim().split(' ')[0] || '').toLowerCase().replace(/[^a-z0-9]/g, '') || 'sales';
const one = async (q, sql, p = []) => (await q.execute(sql, p))[0][0];
const all = async (q, sql, p = []) => (await q.execute(sql, p))[0];

async function uniqueUsername(q, base) {
  let u = base, k = 1;
  while (await one(q, 'SELECT 1 AS x FROM users WHERE username = ?', [u])) u = base + (++k);
  return u;
}
async function newIdSales(q) {
  let max = 0;
  for (const r of await all(q, "SELECT id_sales FROM sales WHERE id_sales LIKE 'SLS-%'")) max = Math.max(max, parseInt(String(r.id_sales).slice(4), 10) || 0);
  return 'SLS-' + String(max + 1).padStart(3, '0');
}
async function createSales(q, nama, username, pass, idSales = null) {
  if (await one(q, 'SELECT 1 AS x FROM sales WHERE nama = ?', [nama])) return null;
  username = await uniqueUsername(q, username !== '' ? username : usernameFromName(nama));
  const id = idSales || await newIdSales(q);
  await q.execute('INSERT INTO sales(id_sales,nama) VALUES(?,?)', [id, nama]);
  await q.execute('INSERT INTO users(username,nama,role,password_hash,id_sales,must_change) VALUES(?,?,?,?,?,1)',
    [username, nama, 'sales', await bcrypt.hash(pass, 10), id]);
  return { u: username, n: nama, id };
}

/* ---------- sesi: cookie bertanda tangan (tanpa penyimpanan di server) ---------- */
const secret = () => process.env.SESSION_SECRET
  || crypto.createHash('sha256').update('sigap:' + (process.env.DB_PASS || '') + ':' + (process.env.DB_USER || '')).digest('hex');
const pv = u => crypto.createHash('sha256').update(String(u.password_hash)).digest('hex').slice(0, 12); // ganti password = sesi lama batal
const mac = p => crypto.createHmac('sha256', secret()).update(p).digest('base64url');
function makeToken(u) {
  const p = `${u.id}.${Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400}.${pv(u)}`;
  return `${p}.${mac(p)}`;
}
function parseToken(req) {
  const m = /(?:^|;\s*)sigap_sid=([^;]+)/.exec(req.headers.get('cookie') || '');
  if (!m) return null;
  const parts = decodeURIComponent(m[1]).split('.');
  if (parts.length !== 4) return null;
  const p = parts.slice(0, 3).join('.');
  const a = Buffer.from(parts[3]), b = Buffer.from(mac(p));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  if (Number(parts[1]) < Date.now() / 1000) return null;
  return { uid: Number(parts[0]), pv: parts[2] };
}
function cookie(req, value, maxAge) {
  const secure = new URL(req.url).hostname === 'localhost' ? '' : '; Secure';
  return `sigap_sid=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}

/* ---------- handler ---------- */
export default async (req) => {
  try {
    return await handle(req);
  } catch (e) {
    if (e instanceof Out) {
      return new Response(JSON.stringify(e.body), {
        status: e.status,
        headers: { 'Content-Type': 'application/json; charset=utf-8', ...BASE_HEADERS, ...e.headers },
      });
    }
    console.error('SIGAP:', e && e.stack || e);
    return new Response(JSON.stringify({ error: explain(e) }), {
      status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8', ...BASE_HEADERS },
    });
  }
};

// Pesan yang membantu menemukan penyebab (tanpa membocorkan host, user, atau password).
function explain(e) {
  const code = String((e && (e.code || e.errno)) || ''), msg = String((e && e.message) || '');
  const tag = code ? ` [${code}]` : '';
  if (/belum diisi/.test(msg)) return msg + '.';
  if (/ENOTFOUND|EAI_AGAIN/.test(code)) return 'Database tidak ditemukan. Periksa DB_HOST di Netlify.' + tag;
  if (/ECONNREFUSED|ETIMEDOUT|ECONNRESET|EHOSTUNREACH|PROTOCOL_CONNECTION_LOST/.test(code) || /timed out|ETIMEDOUT/.test(msg))
    return 'Database tidak bisa dihubungi. Periksa DB_HOST dan DB_PORT, dan pastikan database mengizinkan koneksi dari internet.' + tag;
  if (/ER_ACCESS_DENIED|ER_DBACCESS_DENIED|1045|1044/.test(code + msg)) return 'Akses ke database ditolak. Periksa DB_USER, DB_PASS, dan pastikan database DB_NAME sudah dibuat (di TiDB Cloud, user berawalan, mis. xxxx.root).' + tag;
  if (/ER_BAD_DB_ERROR|1049/.test(code + msg) || /Unknown database/i.test(msg)) return 'Database belum dibuat atau DB_NAME salah. Buat dulu databasenya di penyedia database.' + tag;
  if (/SSL|TLS|certificate|self.signed|HANDSHAKE/i.test(code + msg)) return 'Koneksi aman (TLS) ke database gagal. Coba DB_SSL=no-verify; atau false bila database tanpa TLS.' + tag;
  if (/ER_|SQL/.test(code)) return 'Kesalahan database' + tag + '. Lihat Netlify > Logs > Functions.';
  return 'Server bermasalah' + tag + '. Lihat Netlify > Logs > Functions (cari baris SIGAP).';
}

async function handle(req) {
  const url = new URL(req.url);
  await ensureReady();
  const pool = getPool();

  // Foto: /uploads/<nama>.jpg
  if (url.pathname.startsWith('/uploads/')) {
    const name = decodeURIComponent(url.pathname.slice('/uploads/'.length));
    if (!/^\d{8}_[a-f0-9]{16}\.jpg$/.test(name)) return new Response('Not found', { status: 404 });
    const r = await one(pool, 'SELECT data FROM photo_blobs WHERE name = ?', [name]);
    if (!r) return new Response('Not found', { status: 404 });
    return new Response(r.data, { headers: { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' } });
  }

  const method = req.method;
  const route = url.searchParams.get('r') || '';
  let input = {};
  if (route === 'health') return out({ ok: 1, db: 'terhubung', akun: Number((await one(pool, 'SELECT COUNT(*) AS n FROM users')).n) });
  if (route !== 'boot' && method !== 'POST') err('Metode tidak diizinkan', 405);
  if (method === 'POST') {
    if (!(req.headers.get('content-type') || '').toLowerCase().startsWith('application/json')) err('Permintaan tidak valid', 415);
    try { input = JSON.parse(await req.text()); } catch { input = null; }
    if (!input || typeof input !== 'object' || Array.isArray(input)) err('Data tidak valid');
  }

  const me = async () => {
    const t = parseToken(req);
    if (!t) return null;
    const u = await one(pool, 'SELECT * FROM users WHERE id = ?', [t.uid]);
    return u && pv(u) === t.pv ? u : null;
  };
  const needLogin = async () => (await me()) || err('Sesi berakhir. Masuk lagi.', 401);
  const needAdmin = async () => { const m = await needLogin(); if (m.role !== 'admin') err('Hanya supervisor', 403); return m; };
  const userOut = u => ({ u: u.username, n: u.nama, r: u.role, id: u.id_sales, d: Number(u.must_change) });

  async function loadPosts(onlyId = null) {
    const posts = onlyId ? await all(pool, 'SELECT * FROM posts WHERE id = ?', [onlyId]) : await all(pool, 'SELECT * FROM posts ORDER BY ts DESC');
    const photos = {}, cms = {};
    for (const r of await all(pool, 'SELECT post_id, path FROM post_photos ORDER BY urutan, id')) (photos[r.post_id] ||= []).push(r.path);
    for (const r of await all(pool, 'SELECT post_id, nama, username, teks, ts FROM comments ORDER BY ts, id'))
      (cms[r.post_id] ||= []).push({ n: r.nama, u: r.username, t: r.teks, ts: Number(r.ts) });
    return posts.map(p => {
      let f = {}; try { f = JSON.parse(p.fields) || {}; } catch { /* kosong */ }
      return { id: Number(p.id), ts: Number(p.ts), sales: p.sales_nama, type: p.tipe, area: p.area, f, photos: photos[p.id] || [], note: p.note, cm: cms[p.id] || [] };
    });
  }
  async function bootPayload(m) {
    const users = m.role === 'admin' ? (await all(pool, 'SELECT * FROM users ORDER BY role, id')).map(userOut) : [userOut(m)];
    const team = (await all(pool, "SELECT nama FROM users WHERE role='sales' ORDER BY id")).map(r => r.nama);
    const t = await one(pool, "SELECT v FROM settings WHERE k='target'");
    return { me: userOut(m), users, team, target: Number(t && t.v) || 5, posts: await loadPosts() };
  }
  function decodePhoto(s) {
    const prefix = 'data:image/jpeg;base64,';
    if (typeof s !== 'string' || !s.startsWith(prefix)) err('Foto harus berformat JPEG');
    const b64 = s.slice(prefix.length);
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) err('Foto tidak valid atau terlalu besar');
    const bin = Buffer.from(b64, 'base64');
    if (!bin.length || bin.length > MAX_PHOTO_BYTES) err('Foto tidak valid atau terlalu besar');
    if (!(bin[0] === 0xff && bin[1] === 0xd8 && bin[2] === 0xff)) err('Foto tidak valid');
    return bin;
  }
  const dropPhotos = async (q, paths) => {
    for (const p of paths) await q.execute('DELETE FROM photo_blobs WHERE name = ?', [String(p).split('/').pop()]);
  };

  switch (route) {
    case 'boot': {
      const m = await me();
      return out(m ? await bootPayload(m) : { me: null });
    }

    case 'login': {
      const un = uname(input.u);
      const kUser = 'u:' + un.slice(0, 40);
      const kIp = 'ip:' + String(req.headers.get('x-nf-client-connection-ip') || (req.headers.get('x-forwarded-for') || '?').split(',')[0].trim()).slice(0, 45);
      const since = Math.floor(Date.now() / 1000) - LOGIN_WINDOW;
      if (Math.random() < 0.05) await pool.execute('DELETE FROM login_attempts WHERE ts < ?', [since]);
      const cnt = async k => Number((await one(pool, 'SELECT COUNT(*) AS n FROM login_attempts WHERE k = ? AND ts >= ?', [k, since])).n);
      if (await cnt(kUser) >= LOGIN_MAX_USER || await cnt(kIp) >= LOGIN_MAX_IP) err('Terlalu banyak percobaan gagal. Coba lagi dalam 15 menit.', 429);

      const u = await one(pool, 'SELECT * FROM users WHERE username = ?', [un]);
      let ok = false;
      if (u) { try { ok = await bcrypt.compare(String(input.p ?? ''), u.password_hash); } catch { ok = false; } }
      if (!ok) {
        const now = Math.floor(Date.now() / 1000);
        await pool.execute('INSERT INTO login_attempts(k,ts) VALUES(?,?),(?,?)', [kUser, now, kIp, now]);
        await sleep(400);
        err('Username atau password salah.', 401);
      }
      await pool.execute('DELETE FROM login_attempts WHERE k = ?', [kUser]);
      return out(await bootPayload(u), 200, { 'Set-Cookie': cookie(req, makeToken(u), SESSION_DAYS * 86400) });
    }

    case 'logout':
      return out({ ok: 1 }, 200, { 'Set-Cookie': cookie(req, '', 0) });

    case 'post.add': {
      const m = await needLogin();
      const tipe = String(input.type ?? '');
      if (!TIPE.includes(tipe)) err('Jenis aktivitas tidak valid');
      const nama = m.role === 'admin' ? clean(input.sales, 80) : m.nama;
      const row = await one(pool, "SELECT id_sales FROM users WHERE role='sales' AND nama = ?", [nama]);
      if (!row) err('Sales tidak ditemukan');
      const photos = input.photos;
      if (!Array.isArray(photos) || photos.length < 1 || photos.length > MAX_PHOTOS) err('Tambahkan 1 sampai ' + MAX_PHOTOS + ' foto');
      const f = {};
      if (input.f && typeof input.f === 'object' && !Array.isArray(input.f))
        for (const [k, v] of Object.entries(input.f)) if (typeof v === 'string' || typeof v === 'number') f[clean(k, 60)] = clean(String(v), 120);
      const bins = photos.map(decodePhoto); // validasi dulu sebelum menulis
      const day = new Date().toISOString().slice(0, 10).replaceAll('-', '');
      const conn = await pool.getConnection();
      let id;
      try {
        await conn.beginTransaction();
        const names = [];
        for (const b of bins) {
          const name = `${day}_${crypto.randomBytes(8).toString('hex')}.jpg`;
          await conn.execute('INSERT INTO photo_blobs(name,data) VALUES(?,?)', [name, b]);
          names.push(name);
        }
        const [r] = await conn.execute('INSERT INTO posts(ts,id_sales,sales_nama,tipe,area,fields,note) VALUES(?,?,?,?,?,?,?)', [
          Date.now(), row.id_sales, nama, tipe, clean(input.area ?? 'Lainnya', 60), JSON.stringify(f),
          Array.from(String(input.note ?? '').trim()).slice(0, 1000).join('')]);
        id = Number(r.insertId);
        for (let i = 0; i < names.length; i++) await conn.execute('INSERT INTO post_photos(post_id,path,urutan) VALUES(?,?,?)', [id, 'uploads/' + names[i], i]);
        await conn.commit();
      } catch (e) { await conn.rollback().catch(() => {}); throw e; } finally { conn.release(); }
      const [p] = await loadPosts(id);
      return p ? out(p) : err('Gagal menyimpan', 500);
    }

    case 'post.del': {
      const m = await needLogin();
      const id = Number(input.id) || 0;
      const p = await one(pool, 'SELECT sales_nama FROM posts WHERE id = ?', [id]);
      if (!p) err('Postingan tidak ditemukan', 404);
      if (m.role !== 'admin' && p.sales_nama !== m.nama) err('Tidak boleh menghapus postingan orang lain', 403);
      const paths = (await all(pool, 'SELECT path FROM post_photos WHERE post_id = ?', [id])).map(r => r.path);
      await dropPhotos(pool, paths);
      await pool.execute('DELETE FROM post_photos WHERE post_id = ?', [id]);
      await pool.execute('DELETE FROM comments WHERE post_id = ?', [id]);
      await pool.execute('DELETE FROM posts WHERE id = ?', [id]);
      return out({ ok: 1 });
    }

    case 'comment.add': {
      const m = await needLogin();
      const t = Array.from(String(input.t ?? '').trim()).slice(0, 300).join('');
      if (t === '') err('Komentar kosong');
      const pid = Number(input.id) || 0;
      if (!(await one(pool, 'SELECT 1 AS x FROM posts WHERE id = ?', [pid]))) err('Postingan tidak ditemukan', 404);
      const ts = Date.now();
      await pool.execute('INSERT INTO comments(post_id,user_id,nama,username,teks,ts) VALUES(?,?,?,?,?,?)', [pid, m.id, m.nama, m.username, t, ts]);
      return out({ n: m.nama, u: m.username, t, ts });
    }

    case 'posts.wipe': {
      await needAdmin();
      await pool.query('DELETE FROM photo_blobs');
      await pool.query('DELETE FROM post_photos');
      await pool.query('DELETE FROM comments');
      await pool.query('DELETE FROM posts');
      return out({ ok: 1 });
    }

    case 'user.add': {
      await needAdmin();
      const nama = clean(input.n, 60), username = uname(input.u), pass = String(input.p ?? '');
      const role = input.r === 'admin' ? 'admin' : 'sales';
      if (nama === '' || username === '' || pass.length < MIN_PASS) err('Isi nama, username, dan password (min. ' + MIN_PASS + ' karakter)');
      if (await one(pool, 'SELECT 1 AS x FROM users WHERE username = ?', [username])) err('Username sudah dipakai');
      if (role === 'sales') {
        if (!(await createSales(pool, nama, username, pass))) err('Nama sales sudah terdaftar');
      } else {
        await pool.execute('INSERT INTO users(username,nama,role,password_hash,must_change) VALUES(?,?,?,?,1)', [username, nama, 'admin', await bcrypt.hash(pass, 10)]);
      }
      return out({ ok: 1 });
    }

    case 'user.bulk': {
      await needAdmin();
      const pw = String(input.pw ?? '');
      if (pw.length < MIN_PASS) err('Password awal min. ' + MIN_PASS + ' karakter');
      const rows = Array.isArray(input.rows) ? input.rows.slice(0, 100) : [];
      for (const r of rows) { const p = String((r && r.p) ?? ''); if (clean(r && r.n, 60) !== '' && p !== '' && p.length < MIN_PASS) err('Password per sales min. ' + MIN_PASS + ' karakter'); }
      const created = [], skipped = [];
      const conn = await pool.getConnection();
      try {
        await conn.beginTransaction();
        for (const r of rows) {
          const nama = clean(r && r.n, 60); if (nama === '') continue;
          const pass = String(r.p ?? '');
          const acc = await createSales(conn, nama, uname(r.u), pass !== '' ? pass : pw);
          if (!acc) { skipped.push(nama); continue; }
          created.push({ ...acc, p: pass !== '' ? pass : pw });
        }
        await conn.commit();
      } catch (e) { await conn.rollback().catch(() => {}); throw e; } finally { conn.release(); }
      return out({ created, skipped });
    }

    case 'user.del': {
      const m = await needAdmin();
      const u = await one(pool, 'SELECT * FROM users WHERE username = ?', [uname(input.u)]);
      if (!u) err('Akun tidak ditemukan', 404);
      if (Number(u.id) === Number(m.id)) err('Tidak bisa menghapus akun sendiri');
      // Postingan lama tetap tersimpan (sales_nama disimpan di tiap postingan).
      await pool.execute('UPDATE comments SET user_id = NULL WHERE user_id = ?', [u.id]);
      await pool.execute('DELETE FROM users WHERE id = ?', [u.id]);
      if (u.id_sales) {
        await pool.execute('UPDATE posts SET id_sales = NULL WHERE id_sales = ?', [u.id_sales]);
        await pool.execute('DELETE FROM sales WHERE id_sales = ?', [u.id_sales]);
      }
      return out({ ok: 1 });
    }

    case 'pw.change': {
      const m = await needLogin();
      const p = String(input.p ?? '');
      if (p.length < MIN_PASS) err('Password terlalu pendek (min. ' + MIN_PASS + ' karakter)');
      if ([DEFAULT_SALES_PASSWORD, DEFAULT_ADMIN_PASSWORD].includes(p.toLowerCase())) err('Pilih password yang berbeda dari password awal');
      const hash = await bcrypt.hash(p, 10);
      await pool.execute('UPDATE users SET password_hash = ?, must_change = 0 WHERE id = ?', [hash, m.id]);
      // sesi saat ini tetap berlaku: terbitkan token baru
      return out({ ok: 1 }, 200, { 'Set-Cookie': cookie(req, makeToken({ ...m, password_hash: hash }), SESSION_DAYS * 86400) });
    }

    case 'target.set': {
      await needAdmin();
      const v = Math.min(50, Math.max(1, Math.floor(Number(input.v)) || 5));
      await pool.execute("INSERT INTO settings(k,v) VALUES('target',?) ON DUPLICATE KEY UPDATE v = VALUES(v)", [String(v)]);
      return out({ v });
    }

    default:
      return err('Endpoint tidak ditemukan', 404);
  }
}
