-- SIGAP IM3 (Netlify) - skema + data awal 12 sales. Aman dijalankan berulang (IF NOT EXISTS / INSERT IGNORE).
-- Opsional: tabel juga dibuat otomatis oleh function saat pertama dibuka (hanya akun admin).
SET NAMES utf8mb4;

-- Master sales (sumber: DATABASE_SALES_KOTA_KUPANG.xlsx)
CREATE TABLE IF NOT EXISTS `sales` (
  `id_sales`   VARCHAR(40) NOT NULL,
  `nama`       VARCHAR(80) NOT NULL,
  `aktif`      TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sales`),
  UNIQUE KEY `uq_sales_nama` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Akun login (supervisor dan sales). Akun sales terhubung ke master sales.
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(40) NOT NULL,
  `nama`          VARCHAR(80) NOT NULL,
  `role`          ENUM('admin','sales') NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `id_sales`      VARCHAR(40) NULL DEFAULT NULL,
  `must_change`   TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_id_sales` (`id_sales`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `k` VARCHAR(40) NOT NULL,
  `v` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Postingan aktivitas. ts = epoch milidetik. fields = JSON isian khusus per jenis aktivitas.
CREATE TABLE IF NOT EXISTS `posts` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ts`         BIGINT NOT NULL,
  `id_sales`   VARCHAR(40) NULL DEFAULT NULL,
  `sales_nama` VARCHAR(80) NOT NULL,
  `tipe`       ENUM('Visit Toko','Training','Meeting','Sosialisasi') NOT NULL,
  `area`       VARCHAR(60) NOT NULL,
  `fields`     TEXT NOT NULL,
  `note`       TEXT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_posts_ts` (`ts`),
  KEY `idx_posts_sales` (`sales_nama`, `ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `post_photos` (
  `id`      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` INT UNSIGNED NOT NULL,
  `path`    VARCHAR(255) NOT NULL,
  `urutan`  TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_photos_post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Netlify tidak punya disk permanen: isi foto disimpan di database.
CREATE TABLE IF NOT EXISTS `photo_blobs` (
  `name` VARCHAR(80) NOT NULL,
  `data` MEDIUMBLOB NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `comments` (
  `id`       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id`  INT UNSIGNED NOT NULL,
  `user_id`  INT UNSIGNED NULL DEFAULT NULL,
  `nama`     VARCHAR(80) NOT NULL,
  `username` VARCHAR(40) NOT NULL,
  `teks`     VARCHAR(300) NOT NULL,
  `ts`       BIGINT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_comments_post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Pembatas percobaan login (dipakai api.php)
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `k`  VARCHAR(60) NOT NULL,
  `ts` BIGINT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_la_k_ts` (`k`,`ts`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data awal: 12 sales (Excel), akun, dan pengaturan
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('1-165621715265','FRETEDY TAMONOB',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('1-175210149444','YOHANIS MARTINUS LAMEN',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('1-179956314031','DEDY FLAID',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('1-179956326709','SANOFRYANTO SELAN',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('1-179956599600','ANGELINE MIHA RADJA',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('1-184298556983','ZADRAK YUFIANTO MOOY',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('DSE-KUPANG-01','FREEDOMMAN WADU',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('DSE-KUPANG-02','GODLIEF YERISON MENI',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('DSE-KUPANG-03','PETRUS SAMON BURA',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('DSE-KUPANG-04','GUNTUR MUHAMAD',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('DSE-KUPANG-05','JOHAN AFRIAN',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `sales` (`id_sales`, `nama`, `aktif`, `created_at`) VALUES ('DSE-KUPANG-06','RENALDI APLUGI',1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (1,'admin','Supervisor IM3','admin','$2y$10$IbeueNZCLitUKwa8YvQOuO2OJGM5UEW03gbovqSU8r.2X547fTTlO',NULL,1,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (2,'freedomman','FREEDOMMAN WADU','sales','$2y$10$GddiSoSz8eMdUXxHSDEze.451fPhGSnskEOQ/5AmJ19EyTnA9AVl.','DSE-KUPANG-01',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (3,'godlief','GODLIEF YERISON MENI','sales','$2y$10$6YIlEF0rYcFWcEoCaoPfUeM264rRv/uGR9L9bRiWMiPn2XgXVdEYK','DSE-KUPANG-02',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (4,'petrus','PETRUS SAMON BURA','sales','$2y$10$43B3qRGheAQFflmQd0QYe.Y.uG.iako6GmPaI9UCfF7rKT7LsKolO','DSE-KUPANG-03',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (5,'guntur','GUNTUR MUHAMAD','sales','$2y$10$8EvvY91axgO5KMbkvGo6au3MMbBw33p4dXbM5X.ZhM.f4T/KCIyNO','DSE-KUPANG-04',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (6,'johan','JOHAN AFRIAN','sales','$2y$10$wLNJB5nMY7Mn0IL/xX91a.AqQLC7zD887.yBmbMrlh0ORUo6fJzDq','DSE-KUPANG-05',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (7,'renaldi','RENALDI APLUGI','sales','$2y$10$HV2YF5KSS61j/MStFvFBt.XenVjF5FxgFZhRFM3SE5YicWCftiPQq','DSE-KUPANG-06',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (8,'dedy','DEDY FLAID','sales','$2y$10$j64dmQL4uB/dTwv1czIzy.ywdjG0EoHSB9D7x0.m18tuJV3EgLj2e','1-179956314031',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (9,'angeline','ANGELINE MIHA RADJA','sales','$2y$10$QfpbDmorkrZsfjvPKGDxNuFQ.NRSW4dbUu/oShWQlcUtnfpLLbgiO','1-179956599600',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (10,'fretedy','FRETEDY TAMONOB','sales','$2y$10$Onm9M9agNj3fRrhVlSb51OPBWEhbfq1fOTB.JzC79sHQ.hPNrN.NW','1-165621715265',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (11,'sanofryanto','SANOFRYANTO SELAN','sales','$2y$10$n0aFGJcvSJWtp9lR.wcdGeFZNUkpqAC63MGjKYc8Sw7TQ2z1p0BCy','1-179956326709',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (12,'yohanis','YOHANIS MARTINUS LAMEN','sales','$2y$10$VSCD2NV/wmm6WpNGP/Z7a.8fiNIJYeVZSAAZpUx/qaaPOZ451hfIC','1-175210149444',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `users` (`id`, `username`, `nama`, `role`, `password_hash`, `id_sales`, `must_change`, `created_at`) VALUES (13,'zadrak','ZADRAK YUFIANTO MOOY','sales','$2y$10$FlMhPFzoVb/..j9Z0Bl9IuLsmwA6I0XVADqANvV4zXIlvIJ1on5p6','1-184298556983',0,'2026-10-18 17:55:53');
INSERT IGNORE INTO `settings` (`k`, `v`) VALUES ('target','5');
