// Membuat netlify/functions/api.mjs (satu file mandiri, sudah berisi mysql2 + bcryptjs)
// supaya bisa di-deploy lewat drag and drop tanpa npm install.
import { build } from 'esbuild';
await build({
  entryPoints: ['src/api.src.mjs'],
  bundle: true, platform: 'node', format: 'esm', target: 'node20',
  banner: { js: "import{createRequire as __cr}from'module';const require=__cr(import.meta.url);" },
  outfile: 'netlify/functions/api.mjs', legalComments: 'none',
});
console.log('OK: netlify/functions/api.mjs');
